package com.example.myasynctaskapplication001;

import androidx.appcompat.app.AppCompatActivity;

import android.nfc.Tag;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;



//Multithread App in Android running Asynctask Android AsyncTask Tutorial https://www.youtube.com/watch?v=oHmhmbnQAjM
public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        new longRunningTask().execute();
    }

    private class longRunningTask extends AsyncTask<Void,Void,Void> {
        //Asynctask Methods

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            //you do something like start loading Icon
            Log.d(TAG,"onPreExecute: before task");

        }

        /**
         *
         *
         *
         */


        @Override
        protected Void doInBackground(Void... voids) {

            //AWS network call
            Log.d(TAG,"doInBackground: AWS call");


            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            //you do something likeUpdate UI
            Log.d(TAG,"onPostExecute: after task");


        }
    }

}
