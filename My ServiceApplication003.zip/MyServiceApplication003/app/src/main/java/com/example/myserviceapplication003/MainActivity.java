package com.example.myserviceapplication003;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }



    public void startService(View view) {


        /**
         * Create an intent for a specific component. What we intend to do.
         *Parameters
         * packageContext
         * Context: A Context of the application package implementing this class.
         * cls
         * Class: The component class that is to be used for the intent.
         *
         *
         */


        Intent intent = new Intent(this, MyService003.class);//
        startService(intent);

    }

    public void stopService(View view) {

        Intent intent = new Intent(this, MyService003.class);
        stopService(intent);

    }


}
