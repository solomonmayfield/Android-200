package com.example.myserviceapplication001;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main, menu);//one error, cant find where the tutorial is calling R.menu
        return true;
    }

    public void startMethod(View view) {



        Intent i = new Intent(this, SecondService.class);
        i.putExtra("message", "This is my message");
        startService(i);
    }

    public void stopMethod(View view) {

        Intent i = new Intent(this, MyService.class);
        stopService(i);
    }
}
