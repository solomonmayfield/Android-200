package com.example.myasynctaskapplication002;

import androidx.appcompat.app.AppCompatActivity;

import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;


/**
 *
 * AsyncTask in Android Practicle | Android Tutorial for beginners https://www.youtube.com/watch?v=EThkglxLxSM
 */

public class MainActivity extends AppCompatActivity {

    EditText num1, num2;//have
    Button btn;//call button
    String result = "";
    String strURL = "http://www.telusko.com/addition.htm";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        num1 = (EditText) findViewById(R.id.num1);
        num2 = (EditText) findViewById(R.id.num2);

        btn = (Button) findViewById(R.id.btn);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                int i = Integer.parseInt(num1.getText().toString());
                int j = Integer.parseInt(num2.getText().toString());
                strURL = "www.google.com";

                new MultiplyTask().execute();
            }
        });

    }

    public class MultiplyTask extends AsyncTask<String, String,String>
    {


        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected void onPostExecute(String s) {
          //  super.onPostExecute(s);

            Toast.makeText(MainActivity.this, "The output is " +result, Toast.LENGTH_LONG).show();
        }

        @Override
        protected String doInBackground(String... strings) {
            //send request to server

            try {
                URL url = new URL(strURL);
                HttpURLConnection con = (HttpURLConnection) url.openConnection();//make request to server
                con.setRequestMethod("GET");//specify what method we are using using get method
                con.connect();//initialize connection

                /**
                 *CANT TELL WHY IM GETTING ERRORS IN MY CONNECTION METHODS
                 * 1. I thought it was my uses permission but it looks ok
                 * 2.I thought it was the String URL Address but i wouldnt know.
                 * 3. Is this where running a Log.d comes in?(At this point i just finished the rest of tutorial)
                 */


                //after successful request we need a buffered reader to get the output
                BufferedReader br = new BufferedReader(new InputStreamReader(con.getInputStream()));//con.getinputstream specify wheere were get input
                String value = br.readLine();
                System.out.println("result is " + value);
                result = value;

            } catch (MalformedURLException e) {
                e.printStackTrace();
            }

            return null;
        }

    }

}


